Generated from

DeppinWhite-cursors

with command

./hlCursors .icons/DeppinWhite-cursors/cursors  2 0x10666600  0x10222200 3


using hlCursors with patch to strip down shadows from:

https://github.com/jankotek/hlCursors

https://github.com/mzijlstra/hlCursors
